Thank you for downloading Citrus Clicker

To play extract the contents of the .zip file to an empty folder with the .exe and the assets folder in the same directory

The upgrades along the bottom is the Generators, which increases your passive Citruses Per Second

The upgrades along the side increases the values of your click and various generators

How fast can you buy the mystery box?

Citrus Clicker - Tyler, Tyger, Caleb